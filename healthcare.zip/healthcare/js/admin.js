document.addEventListener('DOMContentLoaded', async () => {
    const appointmentList = document.getElementById('appointment-list');

    try {
        const response = await fetch('http://localhost:3000/api/appointments');
        const appointments = await response.json();

        if (appointments.length === 0) {
            appointmentList.innerHTML = `
                <tr>
                    <td colspan="5" class="empty-state">No appointments found.</td>
                </tr>
            `;
            return;
        }

        // Reverse to show newest first
        appointments.reverse();

        appointmentList.innerHTML = appointments.map(app => `
            <tr>
                <td><strong>${app.name}</strong></td>
                <td><a href="mailto:${app.email}">${app.email}</a></td>
                <td><span style="text-transform: capitalize;">${app.department}</span></td>
                <td>${new Date(app.date).toLocaleDateString()}</td>
                <td>${new Date(app.createdAt).toLocaleString()}</td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error fetching appointments:', error);
        appointmentList.innerHTML = `
            <tr>
                <td colspan="5" class="empty-state" style="color: red;">Failed to load appointments. Make sure the server is running.</td>
            </tr>
        `;
    }
});
