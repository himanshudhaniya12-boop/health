document.addEventListener('DOMContentLoaded', () => {
    // Mobile Menu Toggle
    const mobileMenu = document.getElementById('mobile-menu');
    const navLinks = document.querySelector('.nav-links');

    mobileMenu.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        mobileMenu.classList.toggle('active');
    });

    // Close mobile menu when a link is clicked
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
        });
    });

    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.1)';
            navbar.style.padding = '10px 0';
        } else {
            navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.05)';
            navbar.style.padding = '15px 0';
        }
    });

    // Form Submission Simulation
    const appointmentForm = document.getElementById('appointmentForm');
    const formMessage = document.getElementById('form-message');

    appointmentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const department = document.getElementById('department').value;
        const date = document.getElementById('date').value;

        if(name && email && date && department) {
            try {
                const response = await fetch('http://localhost:3000/api/appointments', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ name, email, department, date })
                });

                if (response.ok) {
                    formMessage.classList.remove('hidden');
                    formMessage.innerText = 'Thank you! Your appointment has been confirmed.';
                    formMessage.style.color = 'var(--primary-color)';
                    appointmentForm.reset();
                } else {
                    formMessage.classList.remove('hidden');
                    formMessage.innerText = 'Error booking appointment. Please try again.';
                    formMessage.style.color = 'red';
                }
            } catch (error) {
                console.error('Error:', error);
                formMessage.classList.remove('hidden');
                formMessage.innerText = 'Network error. Please try again.';
                formMessage.style.color = 'red';
            }
            
            setTimeout(() => {
                formMessage.classList.add('hidden');
            }, 5000);
        } else {
            formMessage.classList.remove('hidden');
            formMessage.innerText = 'Please fill out all fields.';
            formMessage.style.color = 'red';
        }
    });

    // Simple scroll animation (reveal elements as they come into view)
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Apply animation to cards
    const animatedElements = document.querySelectorAll('.service-card, .doctor-card');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(el);
    });
});
