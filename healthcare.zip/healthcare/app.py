from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import json
import os
from datetime import datetime

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

DATA_FILE = 'appointments.json'

def get_appointments():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, 'r') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_appointments(appointments):
    with open(DATA_FILE, 'w') as f:
        json.dump(appointments, f, indent=2)

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/appointments', methods=['POST'])
def create_appointment():
    data = request.get_json()
    
    if not data or not all(k in data for k in ('name', 'email', 'date', 'department')):
        return jsonify({'error': 'All fields are required.'}), 400

    new_appointment = {
        'id': str(int(datetime.now().timestamp() * 1000)),
        'name': data['name'],
        'email': data['email'],
        'department': data['department'],
        'date': data['date'],
        'createdAt': datetime.now().isoformat() + 'Z'
    }

    appointments = get_appointments()
    appointments.append(new_appointment)
    save_appointments(appointments)

    return jsonify({'message': 'Appointment booked successfully!', 'appointment': new_appointment}), 201

@app.route('/api/appointments', methods=['GET'])
def list_appointments():
    return jsonify(get_appointments())

if __name__ == '__main__':
    app.run(port=3000, debug=True)
